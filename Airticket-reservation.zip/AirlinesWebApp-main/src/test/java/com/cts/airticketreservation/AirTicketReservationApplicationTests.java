package com.cts.airticketreservation;

/*import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirTicketReservationApplicationTests {

	@Test
	void contextLoads() {
	}

}*/
