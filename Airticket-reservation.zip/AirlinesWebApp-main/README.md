# AirlinesWebApp

Requirements: Xampp for MySQL and Apache, jdk, eclipse or any similar IDE

TechStack :
Java
Spring Boot
MVC
MySQL

SetUp:
1. Download and extract the zipfile
2. Import the project in Eclipse as a maven project
3. Execute airticketreservation.sql in phpmyadmin to get database and tables created 
4. Modify the database username and password in file- airticketreservation\src\main\resources\connection.properties
5. Run the project as Java Application
6. See MailSetUp.pdf for additional settings
7. For Functional details see AirticketReservationFunctionalDocument.pdf
